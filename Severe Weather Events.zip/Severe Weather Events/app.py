# app.py
from flask import Flask, request, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load the model
with open('E:\\Severe Weather Events\\model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/flood/', methods=['GET', 'POST'])
def predict_weather():
    if request.method == 'POST':
        # Get input values from the form
        rainfall = float(request.form['rainfall'])
        temperature = float(request.form['temperature'])
        water_level = float(request.form['water_level'])
        
        # Make prediction
        features = np.array([[rainfall, temperature, water_level]])
        prediction = model.predict(features)[0]
        
        return render_template('result.html', prediction=prediction)
    
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)